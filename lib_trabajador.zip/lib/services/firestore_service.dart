import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'dart:io';
import 'package:local_auth/local_auth.dart';
import 'package:flutter/services.dart';

class FirestoreService {
  final _db = FirebaseFirestore.instance;
  bool _autenticando = false;

  // Buscar usuario por código
  Future<Map<String, dynamic>?> buscarUsuario(String codigo) async {
    final doc = await _db.collection('usuarios').doc(codigo).get();
    if (doc.exists) return doc.data();
    return null;
  }

  // Guardar device_id en primer login
  Future<void> guardarDeviceId(String codigo, String deviceId) async {
    await _db.collection('usuarios').doc(codigo).update({
      'device_id': deviceId,
      'biometria_registrada': true,
    });
  }

  // Verifica biometría y device id al login
  Future<bool> verificarBiometriaLogin(Map<String, dynamic> usuario) async {
    final auth = LocalAuthentication();

    if (_autenticando) return false;
    _autenticando = true;

    bool autenticado;
    try {
      try {
        final authenticated = await auth.authenticate(
          localizedReason: 'Verifica tu identidad',
          options: const AuthenticationOptions(
            biometricOnly: true,
            stickyAuth: true,
          ),
        );

        autenticado = authenticated;
      } on PlatformException catch (e) {
        if (e.code == 'LockedOut') {
          throw Exception('Demasiados intentos fallidos. Espera 30 segundos.');
        }

        if (e.code == 'PermanentlyLockedOut') {
          throw Exception(
            'Biometría bloqueada. Desbloquea el teléfono manualmente.',
          );
        }

        throw Exception('Error biométrico: ${e.message}');
      }
    } finally {
      _autenticando = false;
    }

    if (!autenticado) return false;

    final info = DeviceInfoPlugin();

    String currentDeviceId;

    if (Platform.isAndroid) {
      final android = await info.androidInfo;
      currentDeviceId = android.id;
    } else {
      final ios = await info.iosInfo;
      currentDeviceId = ios.identifierForVendor ?? 'ios-desconocido';
    }

    final savedDeviceId = usuario['device_id'];

    return currentDeviceId == savedDeviceId;
  }

  // Obtener asistencia del día
  Future<Map<String, dynamic>?> obtenerAsistenciaHoy(String codigo) async {
    final hoy = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final docId = '${codigo}_$hoy';
    final doc = await _db.collection('asistencias').doc(docId).get();
    if (doc.exists) return doc.data();
    return null;
  }

  // Registrar marcación
  Future<String> registrarMarcacion(
    String codigo,
    String sucursal,
    String deviceId,
  ) async {
    final hoy = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final docId = '${codigo}_$hoy';
    final ref = _db.collection('asistencias').doc(docId);

    // Determinar qué marcación corresponde
    final asistencia = await ref.get();
    String tipomarcacion;

    if (!asistencia.exists || asistencia.data()?['entrada'] == null) {
      tipomarcacion = 'entrada';
    } else if (asistencia.data()?['refrigerio_inicio'] == null) {
      tipomarcacion = 'refrigerio_inicio';
    } else if (asistencia.data()?['refrigerio_fin'] == null) {
      tipomarcacion = 'refrigerio_fin';
    } else if (asistencia.data()?['salida'] == null) {
      tipomarcacion = 'salida';
    } else {
      return 'Ya completaste todas las marcaciones de hoy';
    }

    final marcacion = {
      'hora': FieldValue.serverTimestamp(),
      'device_id': deviceId,
    };

    if (!asistencia.exists) {
      // Crear documento de asistencia
      await ref.set({
        'usuario_codigo': codigo,
        'fecha': hoy,
        'sucursal': sucursal,
        tipomarcacion: marcacion,
        'completo': false,
      });
    } else {
      final esUltima = tipomarcacion == 'salida';
      await ref.update({tipomarcacion: marcacion, 'completo': esUltima});
    }

    return tipomarcacion; // retorna el tipo registrado
  }
}
