import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

class QRService {
  /// Valida el QR escaneado contra Firebase.
  /// Retorna un [QRValidacionResult] con éxito/error y mensaje.
  Future<QRValidacionResult> validarQR(
    String qrRaw,
    Map<String, dynamic> usuario,
  ) async {
    try {
      debugPrint('============== QR DEBUG ==============');
      debugPrint('QR RAW: $qrRaw');

      // 1. Decodificar el JSON del QR
      Map<String, dynamic> data;
      try {
        data = jsonDecode(qrRaw) as Map<String, dynamic>;
      } catch (_) {
        return QRValidacionResult.error('QR con formato inválido');
      }

      debugPrint('QR DECODIFICADO: $data');

      final String? sucursalQR = data['token'] != null
          ? data['sucursal']?.toString()
          : null;
      final String? tokenQR = data['token']?.toString();
      final String? empresaQR = data['empresa']?.toString();

      if (sucursalQR == null || tokenQR == null || empresaQR == null) {
        return QRValidacionResult.error('QR incompleto o inválido');
      }

      // 2. Verificar empresa del usuario
      final String empresaUsuario = usuario['empresa']?.toString() ?? '';
      if (empresaQR != empresaUsuario) {
        debugPrint(
          'ERROR: empresa QR ($empresaQR) ≠ usuario ($empresaUsuario)',
        );
        return QRValidacionResult.error('Este QR no pertenece a tu empresa');
      }

      // 3. Verificar sucursal del usuario
      // El usuario debe tener el campo 'sucursal' = doc ID de la tienda
      final String sucursalUsuario = usuario['sucursal']?.toString() ?? '';
      if (sucursalQR != sucursalUsuario) {
        debugPrint(
          'ERROR: sucursal QR ($sucursalQR) ≠ usuario ($sucursalUsuario)',
        );
        return QRValidacionResult.error('Este QR no es de tu tienda asignada');
      }

      // 4. Consultar Firebase para verificar token y expiración
      final doc = await FirebaseFirestore.instance
          .collection('qr_activos')
          .doc(sucursalQR) // doc ID = tiendaId
          .get();

      if (!doc.exists) {
        return QRValidacionResult.error('QR no encontrado en el servidor');
      }

      final qrFirebase = doc.data()!;

      debugPrint('TOKEN QR escaneado : $tokenQR');
      debugPrint('TOKEN FIREBASE     : ${qrFirebase['token']}');

      // 5. Verificar token
      if (qrFirebase['token'] != tokenQR) {
        return QRValidacionResult.error(
          'QR expirado o inválido. Solicita uno nuevo.',
        );
      }

      // 6. Verificar expiración
      final expira = (qrFirebase['expira'] as Timestamp).toDate();
      if (DateTime.now().isAfter(expira)) {
        return QRValidacionResult.error(
          'QR expirado. Espera el siguiente (cada 30 seg)',
        );
      }

      // 7. Verificar activo
      if (qrFirebase['activo'] != true) {
        return QRValidacionResult.error('QR inactivo');
      }

      final nombreTienda =
          qrFirebase['nombre_tienda']?.toString() ?? sucursalQR;

      debugPrint('QR VALIDADO CORRECTAMENTE ✓');
      debugPrint('======================================');

      return QRValidacionResult.exito(
        sucursal: sucursalQR,
        nombreTienda: nombreTienda,
      );
    } catch (e) {
      debugPrint('ERROR GENERAL QR: $e');
      return QRValidacionResult.error('Error al validar QR: $e');
    }
  }
}

class QRValidacionResult {
  final bool valido;
  final String? mensajeError;
  final String? sucursal;
  final String? nombreTienda;

  QRValidacionResult._({
    required this.valido,
    this.mensajeError,
    this.sucursal,
    this.nombreTienda,
  });

  factory QRValidacionResult.exito({
    required String sucursal,
    required String nombreTienda,
  }) {
    return QRValidacionResult._(
      valido: true,
      sucursal: sucursal,
      nombreTienda: nombreTienda,
    );
  }

  factory QRValidacionResult.error(String mensaje) {
    return QRValidacionResult._(valido: false, mensajeError: mensaje);
  }
}
