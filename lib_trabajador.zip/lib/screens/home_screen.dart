import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:local_auth/local_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import '../services/firestore_service.dart';
import '../services/qr_service.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  final Map<String, dynamic> usuario;
  final bool abrirScannerAutomatico;

  const HomeScreen({
    super.key,
    required this.usuario,
    this.abrirScannerAutomatico = false,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, dynamic>? _asistenciaHoy;
  bool _escaneando = false;
  bool _procesando = false;
  bool _qrProcesado = false; // Evita doble detección
  final _auth = LocalAuthentication();
  final _qrService = QRService();

  @override
  void initState() {
    super.initState();
    _cargarAsistencia();
    if (widget.abrirScannerAutomatico) {
      Future.delayed(const Duration(milliseconds: 500), () {
        if (mounted) setState(() => _escaneando = true);
      });
    }
  }

  Future<void> _cargarAsistencia() async {
    final data = await FirestoreService().obtenerAsistenciaHoy(
      widget.usuario['codigo'],
    );
    if (mounted) setState(() => _asistenciaHoy = data);
  }

  /// FLUJO CORRECTO:
  /// 1. Escanear QR
  /// 2. Validar QR contra Firebase (token + empresa + sucursal + expiración)
  /// 3. Si válido → pedir huella
  /// 4. Si huella OK → registrar marcación
  Future<void> _procesarQR(String qrValue) async {
    if (_procesando || _qrProcesado) return;

    setState(() {
      _procesando = true;
      _qrProcesado = true;
    });

    // PASO 1: Validar QR
    final resultado = await _qrService.validarQR(qrValue, widget.usuario);

    if (!resultado.valido) {
      _mostrarMensaje(resultado.mensajeError!, esError: true);
      setState(() {
        _procesando = false;
        _qrProcesado = false;
        _escaneando = false;
      });
      return;
    }

    // PASO 2: Verificar biometría DESPUÉS de validar QR
    bool autenticado = false;
    try {
      autenticado = await _auth.authenticate(
        localizedReason:
            'Confirma tu identidad para registrar asistencia en ${resultado.nombreTienda}',
        options: const AuthenticationOptions(
          biometricOnly: true,
          stickyAuth: true,
        ),
      );
    } catch (e) {
      _mostrarMensaje('Error biométrico: $e', esError: true);
      setState(() {
        _procesando = false;
        _qrProcesado = false;
        _escaneando = false;
      });
      return;
    }

    if (!autenticado) {
      _mostrarMensaje('Verificación biométrica cancelada', esError: true);
      setState(() {
        _procesando = false;
        _qrProcesado = false;
        _escaneando = false;
      });
      return;
    }

    // PASO 3: Registrar marcación en Firebase
    final marcacion = await FirestoreService().registrarMarcacion(
      widget.usuario['codigo'],
      resultado.sucursal!,
      widget.usuario['device_id'] ?? '',
    );

    await _cargarAsistencia();

    _mostrarMensaje(
      marcacion.startsWith('Ya')
          ? marcacion
          : '✓ ${_nombreMarcacion(marcacion)} registrada en ${resultado.nombreTienda}',
      esError: marcacion.startsWith('Ya'),
    );

    setState(() {
      _procesando = false;
      _escaneando = false;
      // No resetear _qrProcesado aquí para que no se dispare de nuevo
    });

    // Permitir nuevo escaneo después de 2 segundos
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _qrProcesado = false);
    });
  }

  String _nombreMarcacion(String key) {
    const nombres = {
      'entrada': 'Entrada',
      'refrigerio_inicio': 'Inicio de refrigerio',
      'refrigerio_fin': 'Fin de refrigerio',
      'salida': 'Salida',
    };
    return nombres[key] ?? key;
  }

  void _mostrarMensaje(String msg, {bool esError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        duration: const Duration(seconds: 3),
        backgroundColor: esError
            ? const Color(0xFFE63232)
            : const Color(0xFF4eca8b),
      ),
    );
  }

  Future<void> _cerrarSesion() async {
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: Text(
          'Cerrar sesión',
          style: GoogleFonts.bebasNeue(
            color: Colors.white,
            fontSize: 22,
            letterSpacing: 1,
          ),
        ),
        content: Text(
          '¿Seguro que quieres cerrar sesión?',
          style: GoogleFonts.robotoCondensed(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancelar', style: TextStyle(color: Colors.grey)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text(
              'Cerrar sesión',
              style: TextStyle(color: Color(0xFFE63232)),
            ),
          ),
        ],
      ),
    );

    if (confirmar == true && mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
        (route) => false,
      );
    }
  }

  Widget _buildMarcacion(String nombre, String key) {
    final hora = _asistenciaHoy?[key]?['hora'];
    final tieneHora = hora != null;
    String horaStr = '--:--';

    if (tieneHora) {
      DateTime fechaHora;
      if (hora is Timestamp) {
        fechaHora = hora.toDate();
      } else if (hora is DateTime) {
        fechaHora = hora;
      } else {
        fechaHora = DateTime.now();
      }
      horaStr = DateFormat('HH:mm').format(fechaHora);
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: tieneHora ? const Color(0xFF4eca8b) : Colors.white24,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              nombre,
              style: GoogleFonts.robotoCondensed(
                fontSize: 12,
                color: Colors.white70,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
              ),
            ),
          ),
          Text(
            tieneHora ? horaStr : 'Pendiente',
            style: GoogleFonts.bebasNeue(
              fontSize: 18,
              letterSpacing: 1,
              color: tieneHora ? const Color(0xFF4eca8b) : Colors.white30,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final marcaciones = [
      ('Entrada', 'entrada'),
      ('Refrig. Inicio', 'refrigerio_inicio'),
      ('Refrig. Fin', 'refrigerio_fin'),
      ('Salida', 'salida'),
    ];
    final completadas = marcaciones
        .where((m) => _asistenciaHoy?[m.$2] != null)
        .length;
    final hoy = DateFormat('EEEE d MMMM', 'es').format(DateTime.now());

    return Scaffold(
      body: Stack(
        children: [
          // Fondo
          Image.asset(
            'assets/fondo.png',
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
          ),

          // ── ESCÁNER QR ──
          if (_escaneando)
            Stack(
              children: [
                MobileScanner(
                  onDetect: (capture) {
                    final barcode = capture.barcodes.firstOrNull;
                    if (barcode?.rawValue != null) {
                      _procesarQR(barcode!.rawValue!);
                    }
                  },
                ),
                // Botón cerrar
                Positioned(
                  top: 60,
                  left: 20,
                  child: IconButton(
                    onPressed: () {
                      setState(() {
                        _escaneando = false;
                        _qrProcesado = false;
                        _procesando = false;
                      });
                    },
                    icon: const Icon(
                      Icons.close,
                      color: Colors.white,
                      size: 32,
                    ),
                  ),
                ),
                // Marco de escaneo
                Center(
                  child: Container(
                    width: 240,
                    height: 240,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: const Color(0xFFE63232),
                        width: 3,
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                ),
                if (_procesando)
                  Container(
                    color: Colors.black54,
                    child: const Center(
                      child: CircularProgressIndicator(
                        color: Color(0xFFE63232),
                      ),
                    ),
                  ),
                Positioned(
                  bottom: 100,
                  left: 0,
                  right: 0,
                  child: Text(
                    'Apunta al QR de la tienda',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 16,
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),

          // ── HOME ──
          if (!_escaneando)
            SafeArea(
              child: Column(
                children: [
                  // Header con botón logout
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 16,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Bienvenido',
                              style: GoogleFonts.robotoCondensed(
                                fontSize: 11,
                                color: Colors.white.withOpacity(0.72),
                                letterSpacing: 1,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            Text(
                              widget.usuario['nombres'] ?? '',
                              style: GoogleFonts.bebasNeue(
                                fontSize: 22,
                                color: Colors.white,
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(
                                  0xFFE63232,
                                ).withOpacity(0.15),
                                border: Border.all(
                                  color: const Color(0xFFE63232),
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                widget.usuario['codigo'] ?? '',
                                style: GoogleFonts.bebasNeue(
                                  fontSize: 14,
                                  color: const Color(0xFFE63232),
                                  letterSpacing: 1,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            GestureDetector(
                              onTap: _cerrarSesion,
                              child: Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.08),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: Colors.white.withOpacity(0.15),
                                  ),
                                ),
                                child: const Icon(
                                  Icons.logout,
                                  color: Colors.white54,
                                  size: 18,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Card asistencias hoy
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.07),
                              border: Border.all(
                                color: Colors.white.withOpacity(0.12),
                              ),
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'ASISTENCIAS HOY',
                                  style: GoogleFonts.robotoCondensed(
                                    fontSize: 11,
                                    color: Colors.white.withOpacity(0.72),
                                    letterSpacing: 1,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                Text(
                                  '$completadas / 4',
                                  style: GoogleFonts.bebasNeue(
                                    fontSize: 36,
                                    color: Colors.white,
                                    letterSpacing: 1,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Row(
                                  children: List.generate(
                                    4,
                                    (i) => Expanded(
                                      child: Container(
                                        height: 4,
                                        margin: const EdgeInsets.only(right: 4),
                                        decoration: BoxDecoration(
                                          color: i < completadas
                                              ? const Color(0xFF4eca8b)
                                              : Colors.white.withOpacity(0.22),
                                          borderRadius: BorderRadius.circular(
                                            2,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  hoy,
                                  style: GoogleFonts.robotoCondensed(
                                    fontSize: 11,
                                    color: Colors.white.withOpacity(0.72),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 16),

                          Text(
                            'MARCACIONES DEL DÍA',
                            style: GoogleFonts.robotoCondensed(
                              fontSize: 11,
                              color: Colors.white.withOpacity(0.72),
                              letterSpacing: 1,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 8),
                          ...marcaciones.map(
                            (m) => _buildMarcacion(m.$1, m.$2),
                          ),

                          const SizedBox(height: 16),

                          // Botón escanear QR
                          GestureDetector(
                            onTap: completadas >= 4
                                ? null
                                : () => setState(() => _escaneando = true),
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                color: completadas >= 4
                                    ? Colors.white.withOpacity(0.03)
                                    : Colors.white.withOpacity(0.06),
                                border: Border.all(
                                  color: completadas >= 4
                                      ? Colors.white.withOpacity(0.05)
                                      : Colors.white.withOpacity(0.1),
                                ),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Column(
                                children: [
                                  Text(
                                    completadas >= 4
                                        ? 'ASISTENCIA COMPLETA'
                                        : 'ESCANEAR QR PARA MARCAR',
                                    style: GoogleFonts.robotoCondensed(
                                      fontSize: 11,
                                      color: completadas >= 4
                                          ? const Color(0xFF4eca8b)
                                          : Colors.white.withOpacity(0.72),
                                      letterSpacing: 1,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(height: 14),
                                  Container(
                                    padding: const EdgeInsets.all(16),
                                    decoration: BoxDecoration(
                                      color: completadas >= 4
                                          ? Colors.white.withOpacity(0.5)
                                          : Colors.white,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Icon(
                                      completadas >= 4
                                          ? Icons.check_circle_outline
                                          : Icons.qr_code_scanner,
                                      size: 80,
                                      color: completadas >= 4
                                          ? const Color(0xFF4eca8b)
                                          : Colors.black,
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Text(
                                    completadas >= 4
                                        ? 'Todas las marcaciones completadas'
                                        : 'Apunta la cámara al QR de la tienda',
                                    style: GoogleFonts.robotoCondensed(
                                      fontSize: 11,
                                      color: Colors.white.withOpacity(0.68),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),

                          const SizedBox(height: 30),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
