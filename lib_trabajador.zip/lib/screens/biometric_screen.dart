import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:local_auth/local_auth.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'dart:io';
import '../services/firestore_service.dart';
import 'home_screen.dart';

class BiometricScreen extends StatefulWidget {
  final Map<String, dynamic> usuario;
  const BiometricScreen({super.key, required this.usuario});
  @override
  State<BiometricScreen> createState() => _BiometricScreenState();
}

class _BiometricScreenState extends State<BiometricScreen> {
  final _auth = LocalAuthentication();
  bool _procesando = false;

  Future<String> _obtenerDeviceId() async {
    final info = DeviceInfoPlugin();
    if (Platform.isAndroid) {
      final data = await info.androidInfo;
      return data.id;
    } else if (Platform.isIOS) {
      final data = await info.iosInfo;
      return data.identifierForVendor ?? 'ios-desconocido';
    }
    return 'unknown';
  }

  Future<void> _registrarHuella() async {
    setState(() => _procesando = true);

    try {
      final disponible = await _auth.canCheckBiometrics;
      if (!disponible) {
        _mostrarError('Este dispositivo no tiene biometría disponible.');
        return;
      }

      final autenticado = await _auth.authenticate(
        localizedReason: 'Registra tu huella para vincular este dispositivo',
        options: const AuthenticationOptions(
          biometricOnly: true,
          stickyAuth: true,
        ),
      );

      if (!autenticado) {
        _mostrarError('Autenticación cancelada. Intenta de nuevo.');
        return;
      }

      final deviceId = await _obtenerDeviceId();
      final codigo = widget.usuario['codigo'];
      await FirestoreService().guardarDeviceId(codigo, deviceId);

      // Actualizar localmente
      final usuarioActualizado = Map<String, dynamic>.from(widget.usuario);
      usuarioActualizado['biometria_registrada'] = true;
      usuarioActualizado['device_id'] = deviceId;

      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => HomeScreen(
              usuario: usuarioActualizado,
              abrirScannerAutomatico: true,
            ),
          ),
        );
      }
    } catch (e) {
      _mostrarError('Error: $e');
    } finally {
      if (mounted) setState(() => _procesando = false);
    }
  }

  void _mostrarError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: const Color(0xFFE63232)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final nombre =
        '${widget.usuario['nombres']} ${widget.usuario['apellidos']}';
    final codigo = widget.usuario['codigo'];

    return Scaffold(
      body: Stack(
        children: [
          Image.asset(
            'assets/fondo.png',
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Column(
                children: [
                  const SizedBox(height: 40),
                  Text(
                    'ALMACEN\nDE REMATES',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.bebasNeue(
                      fontSize: 36,
                      color: Colors.white,
                      letterSpacing: 3,
                      height: 1.1,
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Badge usuario
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.08),
                      border: Border.all(color: Colors.white.withOpacity(0.12)),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          codigo,
                          style: GoogleFonts.robotoCondensed(
                            fontSize: 13,
                            color: const Color(0xFFE63232),
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1,
                          ),
                        ),
                        Text(
                          nombre,
                          style: GoogleFonts.bebasNeue(
                            fontSize: 22,
                            color: Colors.white,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  // Icono biometría
                  Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0xFFE63232),
                        width: 2,
                      ),
                      color: const Color(0xFFE63232).withOpacity(0.08),
                    ),
                    child: const Icon(
                      Icons.fingerprint,
                      size: 56,
                      color: Color(0xFFE63232),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'PRIMER ACCESO',
                    style: GoogleFonts.bebasNeue(
                      fontSize: 28,
                      color: Colors.white,
                      letterSpacing: 3,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Registra tu huella digital para vincular\neste dispositivo. Solo se hace una vez.',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 13,
                      color: Colors.white60,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 30),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _procesando ? null : _registrarHuella,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE63232),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: _procesando
                          ? const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 2,
                              ),
                            )
                          : Text(
                              'REGISTRAR HUELLA',
                              style: GoogleFonts.robotoCondensed(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                                letterSpacing: 2,
                              ),
                            ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Tu biometría nunca sale de este dispositivo',
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 10,
                      color: Colors.white24,
                    ),
                  ),
                  const Spacer(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
